---
name: Feature request
about: Request new features
title: ''
labels: ''
assignees: ''
---

**Describe the new feature**
A clear and concise description of what the feature is.

**Suggest a solution**
If you have ideas for a potential solution, feel free to share them.
